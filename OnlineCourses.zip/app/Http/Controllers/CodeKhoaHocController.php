<?php

namespace App\Http\Controllers;

use App\CodeKhoaHoc;
use Illuminate\Http\Request;

class CodeKhoaHocController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CodeKhoaHoc  $codeKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function show(CodeKhoaHoc $codeKhoaHoc)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CodeKhoaHoc  $codeKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function edit(CodeKhoaHoc $codeKhoaHoc)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CodeKhoaHoc  $codeKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CodeKhoaHoc $codeKhoaHoc)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CodeKhoaHoc  $codeKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function destroy(CodeKhoaHoc $codeKhoaHoc)
    {
        //
    }
}
