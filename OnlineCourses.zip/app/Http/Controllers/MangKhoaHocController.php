<?php

namespace App\Http\Controllers;

use App\MangKhoaHoc;
use Illuminate\Http\Request;

class MangKhoaHocController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MangKhoaHoc  $mangKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function show(MangKhoaHoc $mangKhoaHoc)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MangKhoaHoc  $mangKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function edit(MangKhoaHoc $mangKhoaHoc)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MangKhoaHoc  $mangKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MangKhoaHoc $mangKhoaHoc)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MangKhoaHoc  $mangKhoaHoc
     * @return \Illuminate\Http\Response
     */
    public function destroy(MangKhoaHoc $mangKhoaHoc)
    {
        //
    }
}
