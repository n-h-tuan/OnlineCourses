<?php /* D:\xampp\htdocs\www\OnlineCourses\resources\views/email/code.blade.php */ ?>
<div class="div">
    This is your code: <?php echo e($code); ?>

</div>