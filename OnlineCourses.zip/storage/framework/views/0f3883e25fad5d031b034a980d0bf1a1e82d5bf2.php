<?php /* D:\xampp\htdocs\www\OnlineCourses\resources\views/email/reset_password.blade.php */ ?>
<div class="div">
    <h2 style="color:grey"> Online Courses </h2>
    <br>
    <h1 style="color:cornflowerblue"> Reset Password </h1>
    <br>
    <p>Mật khẩu mới cho tài khoản của bạn: <b style="size:20px"><?php echo e($newPassword); ?></b></p>
    <p>Nếu có vấn đề xảy ra vui lòng liên hệ về địa chỉ email <b style="color:goldenrod"> dtonlinecourse@gmail.com </b></p>
    Thân ái,
    <br>
    Online Courses
</div>