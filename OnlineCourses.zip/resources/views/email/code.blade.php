<div class="div">
    This is your code: {{$code}}
</div>