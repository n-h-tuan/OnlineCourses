<div class="div">
    <h2 style="color:grey"> Online Courses </h2>
    <br>
    <h1 style="color:cornflowerblue"> Code Khóa Học </h1>
    <br>
    <p>Cám ơn bạn đã mua khóa học <b> {{$code->khoa_hoc->TenKH}} </b> tại Online Courses.</p>
    <br>
    <p>Đây là mã code để kích hoạt khóa học của bạn: <b style="size: 20px"> {{$code->code}} </b> </p> 
    <br>
    <p>Nếu có vấn đề xảy ra vui lòng liên hệ về địa chỉ email <b style="color:goldenrod"> dtonlinecourse@gmail.com </b>
    <br></p>
    Thân ái,
    <br><br>
    Online Courses
</div>