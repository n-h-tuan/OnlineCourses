<div class="div">
    <h2 style="color:grey"> Online Courses </h2>
    <h1 style="color:cornflowerblue"> Tài Khoản Ngân Hàng </h1>
    <p>Chào {{$GiangVien->TenGiangVien}}, </p>
    <p>Cám ơn bạn đã tạo thành công khóa học <b> {{$KhoaHoc->TenKH}} </b> tại Online Courses.</p>
    <p>Vui lòng cung cấp số tài khoản ngân hàng của bạn để thuận tiện cho việc mua bán khóa học trực tuyến.</p> 
    <p>Nếu có vấn đề xảy ra vui lòng liên hệ về địa chỉ email <b style="color:goldenrod"> dtonlinecourse@gmail.com </b></p>
    Thân ái,
    <br>
    Online Courses
</div>