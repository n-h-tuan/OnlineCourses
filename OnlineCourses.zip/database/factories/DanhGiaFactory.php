<?php

use Faker\Generator as Faker;

$factory->define(App\DanhGia::class, function (Faker $faker) {
    return [
        //
    ];
});
