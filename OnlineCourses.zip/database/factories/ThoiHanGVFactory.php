<?php

use Faker\Generator as Faker;

$factory->define(App\ThoiHanGV::class, function (Faker $faker) {
    return [
        //
    ];
});
