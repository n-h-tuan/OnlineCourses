<?php

use Faker\Generator as Faker;

$factory->define(App\GiangVien::class, function (Faker $faker) {
    return [
        //
    ];
});
