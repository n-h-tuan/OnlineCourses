<?php

use Faker\Generator as Faker;

$factory->define(App\tai_khoan_ngan_hang::class, function (Faker $faker) {
    return [
        //
    ];
});
