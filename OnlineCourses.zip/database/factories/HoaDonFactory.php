<?php

use Faker\Generator as Faker;

$factory->define(App\HoaDon::class, function (Faker $faker) {
    return [
        //
    ];
});
