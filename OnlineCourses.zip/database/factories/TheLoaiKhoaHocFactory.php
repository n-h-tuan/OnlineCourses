<?php

use Faker\Generator as Faker;

$factory->define(App\TheLoaiKhoaHoc::class, function (Faker $faker) {
    return [
    ];
});
