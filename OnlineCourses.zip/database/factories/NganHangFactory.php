<?php

use Faker\Generator as Faker;

$factory->define(App\NganHang::class, function (Faker $faker) {
    return [
        //
    ];
});
