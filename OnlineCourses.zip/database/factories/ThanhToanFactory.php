<?php

use Faker\Generator as Faker;

$factory->define(App\ThanhToan::class, function (Faker $faker) {
    return [
        //
    ];
});
