<?php

use Faker\Generator as Faker;

$factory->define(App\KhoaHoc::class, function (Faker $faker) {
    return [
        //
    ];
});
