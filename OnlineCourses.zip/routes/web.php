<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('test',function(){
    $day=5;
    $mydate = date('d-m-Y H:i:s');
    $datesum = date('d-m-Y H:i:s',strtotime($mydate.' + '.$day.' months')); 
    //Thay "Hours" thành "days || months || ...." thêm "s" phía cuối => dùng thằng nào thì sẽ cộng vào thằng đó
    return $datesum;
});
Route::get('test01',function(){
    $day= strtotime('2019-03-05T17:00:00.000000Z');
    // $mnd = DateTime::createFromFormat('Y-m-d',$day)->format('d-m-Y');
    $newFormat = date('d-m-Y H:i:s',$day);
    return $newFormat;
});
