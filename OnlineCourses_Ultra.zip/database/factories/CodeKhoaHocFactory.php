<?php

use Faker\Generator as Faker;

$factory->define(App\CodeKhoaHoc::class, function (Faker $faker) {
    return [
        //
    ];
});
