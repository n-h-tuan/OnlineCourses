<?php

use Faker\Generator as Faker;

$factory->define(App\MangKhoaHoc::class, function (Faker $faker) {
    return [
        //
    ];
});
